"use strict";
(() => {
  // popup/popup.ts
  var app = document.getElementById("app");
  function sendMsg(msg) {
    return new Promise((resolve, reject) => {
      chrome.runtime.sendMessage(msg, (response) => {
        if (chrome.runtime.lastError) return reject(new Error(chrome.runtime.lastError.message));
        if (response?.error) return reject(new Error(response.error));
        resolve(response);
      });
    });
  }
  var LOGO_SVG = `<svg width="24" height="24" viewBox="0 0 128 128" fill="none" xmlns="http://www.w3.org/2000/svg">
  <circle cx="64" cy="64" r="64" fill="#5a9471"/>
  <circle cx="64" cy="64" r="55" fill="none" stroke="rgba(255,255,255,0.18)" stroke-width="1.5"/>
  <path d="M64 25 L92 69 L64 113 L36 69 Z" fill="#ffffff"/>
  <path d="M64 49 L64 113" stroke="#477857" stroke-width="5" stroke-linecap="round"/>
  <ellipse cx="64" cy="51" rx="10" ry="7" fill="#477857"/>
  <path d="M44 83 Q54 91 64 93 Q74 91 84 83" stroke="rgba(255,255,255,0.22)" stroke-width="2.5" fill="none" stroke-linecap="round"/>
</svg>`;
  var GOOGLE_SVG = `<svg width="16" height="16" viewBox="0 0 48 48" xmlns="http://www.w3.org/2000/svg">
  <path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"/>
  <path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"/>
  <path fill="#FBBC05" d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z"/>
  <path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.18 1.48-4.97 2.31-8.16 2.31-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"/>
</svg>`;
  function renderLogin(errorMsg = "") {
    app.innerHTML = `
    <div class="header">
      <span class="header-logo">${LOGO_SVG}</span>
      <div>
        <div class="header-title">signedinbox</div>
        <div class="header-subtitle">Sign in to stamp emails</div>
      </div>
    </div>
    <div class="content">
      <button id="sign-in-google-btn" class="btn-google">${GOOGLE_SVG} Continue with Google</button>
      <div class="divider">or</div>
      <div class="field">
        <label>Email</label>
        <input id="email" type="email" placeholder="you@example.com" autocomplete="email" />
      </div>
      <div class="field">
        <label>Password</label>
        <input id="password" type="password" autocomplete="current-password" />
      </div>
      ${errorMsg ? `<p class="error">${errorMsg}</p>` : ""}
      <button id="sign-in-btn" class="btn btn-primary">Sign in</button>
    </div>
  `;
    const signInBtn = document.getElementById("sign-in-btn");
    const emailInput = document.getElementById("email");
    const passwordInput = document.getElementById("password");
    const googleBtn = document.getElementById("sign-in-google-btn");
    googleBtn.addEventListener("click", async () => {
      googleBtn.disabled = true;
      googleBtn.innerHTML = `${GOOGLE_SVG} Signing in...`;
      try {
        await sendMsg({ type: "SIGN_IN_GOOGLE" });
        await renderMain();
      } catch (err) {
        renderLogin(err instanceof Error ? err.message : "Google sign in failed");
      }
    });
    signInBtn.addEventListener("click", async () => {
      signInBtn.disabled = true;
      signInBtn.textContent = "Signing in...";
      try {
        await sendMsg({ type: "SIGN_IN", email: emailInput.value, password: passwordInput.value });
        await renderMain();
      } catch (err) {
        renderLogin(err instanceof Error ? err.message : "Sign in failed");
      }
    });
  }
  async function renderMain() {
    app.innerHTML = `
    <div class="header">
      <span class="header-logo">${LOGO_SVG}</span>
      <div>
        <div class="header-title">signedinbox</div>
        <div class="header-subtitle">Ready to stamp</div>
      </div>
    </div>
    <div class="content">
      <div class="field">
        <label>Active sender</label>
        <select id="sender-select"><option value="">Loading...</option></select>
        <p id="sender-meta" class="meta"></p>
      </div>
    </div>
    <div class="footer">
      <a href="https://signedinbox.com/dashboard" target="_blank">Dashboard</a>
      <button id="sign-out-btn" class="btn btn-secondary btn-compact">Sign out</button>
    </div>
  `;
    const { auth } = await sendMsg({ type: "GET_AUTH" });
    if (!auth) {
      renderLogin();
      return;
    }
    let senders = [];
    try {
      const res = await sendMsg({ type: "GET_SENDERS" });
      senders = res.senders;
    } catch (err) {
      app.querySelector(".content").innerHTML += `<p class="error">Failed to load senders: ${err instanceof Error ? err.message : String(err)}</p>`;
      return;
    }
    const select = document.getElementById("sender-select");
    const meta = document.getElementById("sender-meta");
    if (senders.length === 0) {
      select.innerHTML = '<option value="">No senders \u2014 create one in the dashboard</option>';
    } else {
      select.innerHTML = senders.map(
        (s) => `<option value="${s.id}">${s.display_name} &lt;${s.email}&gt;${s.verified_email ? "" : " (unverified)"}</option>`
      ).join("");
    }
    const stored = await chrome.storage.local.get("activeSenderId");
    if (stored.activeSenderId && senders.find((s) => s.id === stored.activeSenderId)) {
      select.value = stored.activeSenderId;
    }
    function updateMeta() {
      const sender = senders.find((s) => s.id === select.value);
      if (!sender) {
        meta.textContent = "";
        return;
      }
      meta.textContent = sender.verified_email ? `${sender.stamp_count ?? 0} stamps` : "Email not verified \u2014 verify in the dashboard before stamping";
      chrome.storage.local.set({ activeSenderId: sender.id });
    }
    select.addEventListener("change", updateMeta);
    updateMeta();
    document.getElementById("sign-out-btn").addEventListener("click", async () => {
      await sendMsg({ type: "SIGN_OUT" });
      renderLogin();
    });
  }
  (async () => {
    try {
      const { auth } = await sendMsg({ type: "GET_AUTH" });
      if (auth) {
        await renderMain();
      } else {
        renderLogin();
      }
    } catch {
      renderLogin();
    }
  })();
})();
//# sourceMappingURL=popup.js.map
