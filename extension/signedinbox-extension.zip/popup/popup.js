"use strict";(()=>{var o=document.getElementById("app");function d(i){return new Promise((t,n)=>{chrome.runtime.sendMessage(i,a=>{if(chrome.runtime.lastError)return n(new Error(chrome.runtime.lastError.message));if(a?.error)return n(new Error(a.error));t(a)})})}var m=`<svg width="24" height="24" viewBox="0 0 128 128" fill="none" xmlns="http://www.w3.org/2000/svg">
  <circle cx="64" cy="64" r="64" fill="#5a9471"/>
  <circle cx="64" cy="64" r="55" fill="none" stroke="rgba(255,255,255,0.18)" stroke-width="1.5"/>
  <path d="M64 25 L92 69 L64 113 L36 69 Z" fill="#ffffff"/>
  <path d="M64 49 L64 113" stroke="#477857" stroke-width="5" stroke-linecap="round"/>
  <ellipse cx="64" cy="51" rx="10" ry="7" fill="#477857"/>
  <path d="M44 83 Q54 91 64 93 Q74 91 84 83" stroke="rgba(255,255,255,0.22)" stroke-width="2.5" fill="none" stroke-linecap="round"/>
</svg>`,g=`<svg width="16" height="16" viewBox="0 0 48 48" xmlns="http://www.w3.org/2000/svg">
  <path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"/>
  <path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"/>
  <path fill="#FBBC05" d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z"/>
  <path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.18 1.48-4.97 2.31-8.16 2.31-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"/>
</svg>`;function l(i=""){o.innerHTML=`
    <div class="header">
      <span class="header-logo">${m}</span>
      <div>
        <div class="header-title">signedinbox</div>
        <div class="header-subtitle">Sign in to stamp emails</div>
      </div>
    </div>
    <div class="content">
      <button id="sign-in-google-btn" class="btn-google">${g} Continue with Google</button>
      <div class="divider">or</div>
      <div class="field">
        <label>Email</label>
        <input id="email" type="email" placeholder="you@example.com" autocomplete="email" />
      </div>
      <div class="field">
        <label>Password</label>
        <input id="password" type="password" autocomplete="current-password" />
      </div>
      ${i?`<p class="error">${i}</p>`:""}
      <button id="sign-in-btn" class="btn btn-primary">Sign in</button>
    </div>
  `;let t=document.getElementById("sign-in-btn"),n=document.getElementById("email"),a=document.getElementById("password"),r=document.getElementById("sign-in-google-btn");r.addEventListener("click",async()=>{r.disabled=!0,r.innerHTML=`${g} Signing in...`;try{await d({type:"SIGN_IN_GOOGLE"}),await c()}catch(s){l(s instanceof Error?s.message:"Google sign in failed")}}),t.addEventListener("click",async()=>{t.disabled=!0,t.textContent="Signing in...";try{await d({type:"SIGN_IN",email:n.value,password:a.value}),await c()}catch(s){l(s instanceof Error?s.message:"Sign in failed")}})}async function c(){o.innerHTML=`
    <div class="header">
      <span class="header-logo">${m}</span>
      <div>
        <div class="header-title">signedinbox</div>
        <div class="header-subtitle">Ready to stamp</div>
      </div>
    </div>
    <div class="content">
      <div class="field">
        <label>Active sender</label>
        <select id="sender-select"><option value="">Loading...</option></select>
        <p id="sender-meta" class="meta"></p>
      </div>
    </div>
    <div class="footer">
      <a href="https://signedinbox.com/dashboard" target="_blank">Dashboard</a>
      <button id="sign-out-btn" class="btn btn-secondary btn-compact">Sign out</button>
    </div>
  `;let{auth:i}=await d({type:"GET_AUTH"});if(!i){l();return}let t=[];try{t=(await d({type:"GET_SENDERS"})).senders}catch(e){o.querySelector(".content").innerHTML+=`<p class="error">Failed to load senders: ${e instanceof Error?e.message:String(e)}</p>`;return}let n=document.getElementById("sender-select"),a=document.getElementById("sender-meta");t.length===0?n.innerHTML='<option value="">No senders \u2014 create one in the dashboard</option>':n.innerHTML=t.map(e=>`<option value="${e.id}">${e.display_name} &lt;${e.email}&gt;${e.verified_email?"":" (unverified)"}</option>`).join("");let r=await chrome.storage.local.get("activeSenderId");r.activeSenderId&&t.find(e=>e.id===r.activeSenderId)&&(n.value=r.activeSenderId);function s(){let e=t.find(u=>u.id===n.value);if(!e){a.textContent="";return}a.textContent=e.verified_email?`${e.stamp_count??0} stamps`:"Email not verified \u2014 verify in the dashboard before stamping",chrome.storage.local.set({activeSenderId:e.id})}n.addEventListener("change",s),s(),document.getElementById("sign-out-btn").addEventListener("click",async()=>{await d({type:"SIGN_OUT"}),l()})}(async()=>{try{let{auth:i}=await d({type:"GET_AUTH"});i?await c():l()}catch{l()}})();})();
