"use strict";
(() => {
  // offscreen/turnstile.ts
  var FRAME_ORIGIN = "https://signedinbox.com";
  var TOKEN_TTL_MS = 4 * 60 * 1e3;
  var cachedToken = null;
  var cachedTokenAt = 0;
  var pendingResolve = null;
  var pendingReject = null;
  function getFrame() {
    return document.getElementById("turnstile-frame");
  }
  function requestFreshToken() {
    const tryRequest = () => {
      const frame = getFrame();
      if (frame?.contentWindow) {
        frame.contentWindow.postMessage({ type: "REQUEST_TOKEN" }, FRAME_ORIGIN);
      } else {
        setTimeout(tryRequest, 100);
      }
    };
    tryRequest();
  }
  window.addEventListener("message", (event) => {
    if (event.origin !== FRAME_ORIGIN) return;
    if (event.data?.type === "TURNSTILE_TOKEN") {
      const token = event.data.token;
      if (pendingResolve) {
        pendingResolve(token);
        pendingResolve = null;
        pendingReject = null;
        requestFreshToken();
      } else {
        cachedToken = token;
        cachedTokenAt = Date.now();
      }
    } else if (event.data?.type === "TURNSTILE_NEEDS_INTERACTION") {
      chrome.runtime.sendMessage({ type: "TURNSTILE_NEEDS_INTERACTION" });
    } else if (event.data?.type === "TURNSTILE_ERROR") {
      if (pendingReject) {
        pendingReject(new Error(`Turnstile error: ${event.data.error}`));
        pendingResolve = null;
        pendingReject = null;
      } else {
        cachedToken = null;
      }
    }
  });
  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (message.type !== "GET_TURNSTILE_TOKEN") return;
    if (cachedToken && Date.now() - cachedTokenAt < TOKEN_TTL_MS) {
      const token = cachedToken;
      cachedToken = null;
      sendResponse({ token });
      requestFreshToken();
      return true;
    }
    cachedToken = null;
    new Promise((resolve, reject) => {
      pendingResolve = resolve;
      pendingReject = reject;
      requestFreshToken();
    }).then((token) => sendResponse({ token })).catch((err) => sendResponse({ error: String(err) }));
    return true;
  });
})();
//# sourceMappingURL=turnstile.js.map
