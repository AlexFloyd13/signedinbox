// lib/auth.ts
var SUPABASE_URL = "https://gldyvewzkdzfydvneizq.supabase.co";
var SUPABASE_ANON_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImdsZHl2ZXd6a2R6Znlkdm5laXpxIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzIxMzcyNDAsImV4cCI6MjA4NzcxMzI0MH0.gc9x9tFkH5Rv2iJPJyWiUFuQVPuuJD71Bd_SUsSaWGg";
async function signInWithPassword(email, password) {
  const res = await fetch(`${SUPABASE_URL}/auth/v1/token?grant_type=password`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      apikey: SUPABASE_ANON_KEY
    },
    body: JSON.stringify({ email, password })
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error_description || err.msg || "Sign in failed");
  }
  const data = await res.json();
  return {
    accessToken: data.access_token,
    refreshToken: data.refresh_token,
    email: data.user.email,
    userId: data.user.id
  };
}
async function refreshSession(refreshToken) {
  const res = await fetch(`${SUPABASE_URL}/auth/v1/token?grant_type=refresh_token`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      apikey: SUPABASE_ANON_KEY
    },
    body: JSON.stringify({ refresh_token: refreshToken })
  });
  if (!res.ok) throw new Error("Session refresh failed");
  const data = await res.json();
  return {
    accessToken: data.access_token,
    refreshToken: data.refresh_token,
    email: data.user.email,
    userId: data.user.id
  };
}

// lib/storage.ts
async function getAuth() {
  const result = await chrome.storage.local.get("auth");
  return result.auth ?? null;
}
async function setAuth(auth) {
  await chrome.storage.local.set({ auth });
}
async function clearAuth() {
  await chrome.storage.local.remove("auth");
}
async function setActiveSenderId(id) {
  await chrome.storage.local.set({ activeSenderId: id });
}

// lib/api.ts
var API_BASE = "https://signedinbox.com/api/v1";
async function getSenders(accessToken) {
  const res = await fetch(`${API_BASE}/stamps?action=senders`, {
    headers: { Authorization: `Bearer ${accessToken}` }
  });
  if (!res.ok) throw new Error("Failed to fetch senders");
  const data = await res.json();
  return data.senders;
}
async function claimAuthEmail(accessToken) {
  const res = await fetch(`${API_BASE}/stamps`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${accessToken}`
    },
    body: JSON.stringify({ action: "claim-auth-email" })
  });
  if (!res.ok) return null;
  const data = await res.json();
  return data.sender ?? null;
}
async function createStamp(accessToken, senderId, turnstileToken, opts = {}) {
  const res = await fetch(`${API_BASE}/stamps`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${accessToken}`
    },
    body: JSON.stringify({
      sender_id: senderId,
      turnstile_token: turnstileToken,
      client_type: "chrome_extension",
      ...opts.recipientEmail && { recipient_email: opts.recipientEmail },
      ...opts.contentHash && { content_hash: opts.contentHash },
      ...opts.isMassSend && { is_mass_send: true },
      ...opts.declaredRecipientCount && { declared_recipient_count: opts.declaredRecipientCount }
    })
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error || "Failed to create stamp");
  }
  return res.json();
}

// background/background.ts
async function ensureOffscreenDocument() {
  const existing = await chrome.offscreen.hasDocument?.().catch(() => false);
  if (!existing) {
    await chrome.offscreen.createDocument({
      url: "offscreen/turnstile.html",
      reasons: ["IFRAME_SCRIPTING"],
      justification: "Silently verify Cloudflare Turnstile for stamp creation"
    });
  }
}
ensureOffscreenDocument().catch(() => {
});
var _needsInteractionCallback = null;
async function getTurnstileTokenSilent() {
  await ensureOffscreenDocument();
  return new Promise((resolve, reject) => {
    const absoluteTimer = setTimeout(() => {
      _needsInteractionCallback = null;
      reject(new Error("Verification timed out"));
    }, 5e3);
    _needsInteractionCallback = () => {
      clearTimeout(absoluteTimer);
      _needsInteractionCallback = null;
      reject(new Error("Interactive challenge required"));
    };
    chrome.runtime.sendMessage({ type: "GET_TURNSTILE_TOKEN" }, (response) => {
      clearTimeout(absoluteTimer);
      _needsInteractionCallback = null;
      if (chrome.runtime.lastError) return reject(new Error(chrome.runtime.lastError.message));
      if (response?.error) return reject(new Error(response.error));
      resolve(response.token);
    });
  });
}
var _challengeResolve = null;
var _challengeReject = null;
var _challengeWindowId = null;
async function getTurnstileTokenPopup() {
  if (_challengeWindowId !== null) {
    await chrome.windows.remove(_challengeWindowId).catch(() => {
    });
    _challengeWindowId = null;
  }
  return new Promise((resolve, reject) => {
    _challengeResolve = resolve;
    _challengeReject = reject;
    chrome.windows.create({
      url: chrome.runtime.getURL("challenge/challenge.html"),
      type: "popup",
      width: 360,
      height: 160,
      focused: true
    }).then((win) => {
      _challengeWindowId = win?.id ?? null;
      const onRemoved = (removedId) => {
        if (removedId !== _challengeWindowId) return;
        chrome.windows.onRemoved.removeListener(onRemoved);
        _challengeWindowId = null;
        if (_challengeReject) {
          _challengeReject(new Error("Verification cancelled"));
          _challengeResolve = null;
          _challengeReject = null;
        }
      };
      chrome.windows.onRemoved.addListener(onRemoved);
      setTimeout(() => {
        if (_challengeReject) {
          _challengeReject(new Error("Verification timed out"));
          _challengeResolve = null;
          _challengeReject = null;
          if (_challengeWindowId !== null) {
            chrome.windows.remove(_challengeWindowId).catch(() => {
            });
            _challengeWindowId = null;
          }
        }
      }, 12e4);
    });
  });
}
async function getTurnstileToken() {
  try {
    return await getTurnstileTokenSilent();
  } catch {
    return await getTurnstileTokenPopup();
  }
}
async function getValidToken() {
  const auth = await getAuth();
  if (!auth) throw new Error("Not authenticated");
  try {
    const refreshed = await refreshSession(auth.refreshToken);
    await setAuth(refreshed);
    return refreshed.accessToken;
  } catch {
    await clearAuth();
    throw new Error("Session expired \u2014 please sign in again");
  }
}
chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  (async () => {
    try {
      switch (message.type) {
        case "SIGN_IN": {
          const auth = await signInWithPassword(message.email, message.password);
          await setAuth(auth);
          sendResponse({ success: true, email: auth.email });
          break;
        }
        case "SIGN_IN_GOOGLE": {
          const redirectUrl = chrome.identity.getRedirectURL("oauth2");
          const authUrl = new URL(`${SUPABASE_URL}/auth/v1/authorize`);
          authUrl.searchParams.set("provider", "google");
          authUrl.searchParams.set("redirect_to", redirectUrl);
          const responseUrl = await new Promise((resolve, reject) => {
            chrome.identity.launchWebAuthFlow(
              { url: authUrl.toString(), interactive: true },
              (url) => {
                if (chrome.runtime.lastError) return reject(new Error(chrome.runtime.lastError.message));
                if (!url) return reject(new Error("OAuth cancelled"));
                resolve(url);
              }
            );
          });
          const hash = new URL(responseUrl).hash.slice(1);
          const params = new URLSearchParams(hash);
          const accessToken = params.get("access_token");
          const refreshToken = params.get("refresh_token");
          if (!accessToken || !refreshToken) throw new Error("OAuth response missing tokens");
          const userRes = await fetch(`${SUPABASE_URL}/auth/v1/user`, {
            headers: {
              Authorization: `Bearer ${accessToken}`,
              apikey: SUPABASE_ANON_KEY
            }
          });
          if (!userRes.ok) throw new Error("Failed to fetch user after OAuth");
          const userData = await userRes.json();
          const auth = {
            accessToken,
            refreshToken,
            email: userData.email,
            userId: userData.id
          };
          await setAuth(auth);
          await claimAuthEmail(accessToken).catch(() => null);
          sendResponse({ success: true, email: auth.email });
          break;
        }
        case "SIGN_OUT": {
          await clearAuth();
          sendResponse({ success: true });
          break;
        }
        case "GET_AUTH": {
          const auth = await getAuth();
          sendResponse({ auth });
          break;
        }
        case "GET_SENDERS": {
          const token = await getValidToken();
          let senders = await getSenders(token);
          if (senders.length === 0) {
            const claimed = await claimAuthEmail(token).catch(() => null);
            if (claimed) senders = [claimed];
          }
          sendResponse({ senders });
          break;
        }
        case "CREATE_STAMP": {
          const token = await getValidToken();
          let senderId = message.senderId;
          if (!senderId) {
            const senders = await getSenders(token);
            const verified = senders.filter((s) => s.verified_email);
            if (verified.length === 0) {
              throw new Error("No verified senders found. Visit signedinbox.com/dashboard to verify your email.");
            }
            senderId = verified[0].id;
            await setActiveSenderId(senderId);
          }
          let contentHash;
          const { recipientEmail, subjectHint, recipientCount = 1 } = message;
          if (recipientEmail && subjectHint) {
            const input = `${senderId}|${recipientEmail.toLowerCase()}|${subjectHint}`;
            const buf = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(input));
            contentHash = Array.from(new Uint8Array(buf)).map((b) => b.toString(16).padStart(2, "0")).join("");
          }
          const isMassSend = recipientCount > 1;
          const turnstileToken = await getTurnstileToken();
          const stamp = await createStamp(token, senderId, turnstileToken, {
            recipientEmail,
            contentHash,
            isMassSend,
            declaredRecipientCount: isMassSend ? recipientCount : void 0
          });
          sendResponse({ stamp });
          break;
        }
        case "TURNSTILE_NEEDS_INTERACTION": {
          _needsInteractionCallback?.();
          sendResponse({ success: true });
          break;
        }
        case "CHALLENGE_COMPLETE": {
          if (message.error) {
            _challengeReject?.(new Error(message.error));
            _challengeResolve = null;
            _challengeReject = null;
          } else {
            _challengeResolve?.(message.token);
            _challengeResolve = null;
            _challengeReject = null;
          }
          _challengeWindowId = null;
          sendResponse({ success: true });
          break;
        }
        default:
          sendResponse({ error: `Unknown message type: ${message.type}` });
      }
    } catch (err) {
      sendResponse({ error: err instanceof Error ? err.message : String(err) });
    }
  })();
  return true;
});
//# sourceMappingURL=background.js.map
